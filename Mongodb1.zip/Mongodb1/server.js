const mongoose = require("mongoose");
let connectToMDB = async () => {
  try {
    await mongoose.connect("mongodb://localhost:27017/Mern23");
    console.log("Connected to MDB");
    insertDataIntoDB();
  } catch (err) {
    if (err) {
      console.log("Unable to connect to db");
    }
  }
};

let studentSchema = new mongoose.Schema({
  name: String,
  batchId: String,
  gender: String,
  maritalStatus: String,
  email: String,
  mobileNo: String,
});

let Student = new mongoose.model("student", studentSchema);

let insertDataIntoDB = async () => {
  let saranya = new Student({
    name: "SakthiSaranya K",
    batchId: "MERN 2303",
    gender: "Female",
    maritalStatus: "Single",
    email: "saranya@gmail.com",
    mobileNo: "+91-786745678",
  });

  //await saranya.save();

  let SakthiSaranyaKamaraj = new Student({
    name: "SakthiSaranyaKamaraj",
    batchId: "MERN 2303",
    gender: "Female",
    maritalStatus: "Single",
    email: "saranya223@gmail.com",
    mobileNo: "+91-786545668",
  });

  //await SakthiSaranyaKamaraj.save();

  await Student.insertMany([saranya, SakthiSaranyaKamaraj]);

  console.log("Inserted into db");
};

connectToMDB();
