import './App.css';

function App() {
  
let alphabets = `ABCDEFGHIJKLMNOPQRSTUVWXYZAABBCCNNNJJJDKKSSJJJBBCHFH`;
let PMName = "Honourable Shri.Narendra Modi ji";
let India  = "Unity Nation";

return (
  <div className="App">

<button className = "button1"onClick={()=>{



for(let i=0;i<alphabets.length;i++)
{
console.log(alphabets.charAt(i));
}


console.log(alphabets.charAt(0));
console.log(alphabets.length);

}}>charAt</button>

<button className = "button1"onClick={()=>{
let news = "Vande Bharat Express";
console.log(news.concat("rectly launched between secunderabad to Vishakapatnam"));
let news1 = "chennai super kings & Csk team has huge fan support";
console.log(news1.concat(" csk won the IPL Champion 5th Time"));
}}>concat</button>


<button className = "button1" onClick={()=>{
console.log(PMName.startsWith("Honour"));
console.log(India.startsWith("unity"));

}}>startsWith</button>


<button className = "button1"onClick={()=>{

console.log(PMName.endsWith("ji"));

}}>endsWith</button>



<button className = "button1" onClick={()=>{
console.log(PMName.includes("Honourable"));

}}>includes</button>



<button className = "button1" onClick={()=>{

let punishment = " I wont make any error in  mycode "
console.log(punishment.repeat(100000));
}}>repeat</button>


<button className = "button1" onClick={()=>{

  let info = "India is incrediable country"

  console.log(info.toLowerCase());
  console.log(info.toUpperCase());
}}>UpperCase,LowerCase</button>


<button className = "button1" onClick={()=>{
  let countryName = "  Hamara  Bharath      ";
  console.log(`.........>>${countryName}<<<....`);
  console.log(`.........>>${countryName.trim()}<<<....`);
  console.log(`.........>>${countryName.trimEnd()}@@@<<<....`);
}}>trim,trimStart,trimEnd</button>
    </div>
  );
}

export default App;
