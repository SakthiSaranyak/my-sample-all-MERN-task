import './App.css';

function App() {
  
  let alphabets = `ABCDEFGHIJKLMNOPQRSTUVWXYZAABBCCNNNJJJDKKSSJJJBBCHFFFFH அஆஇஈஉஊஎஏஐஒஓஔக்ககிகீகுகூகெகேகைகொகோகௌ എഎഎഇഞാൻഇ  `;
  let PMName = "Honourable Shri.Narendra Modi ji";
  let India  = "Unity Nation";
  
  return (
    <div className="App">
  
  <button className = "button1"onClick={()=>{
  
  
  
  for(let i=0;i<alphabets.length;i++)
  {
  console.log(alphabets.charAt(i));
  }
  
  
  console.log(alphabets.charAt(0));
  console.log(alphabets.length);
  
  }}>charAt</button>
  
  <button className = "button1"onClick={()=>{
  let news = "Vande Bharat Express";
  console.log(news.concat("rectly launched between secunderabad to Vishakapatnam"));
  let news1 = "chennai super kings & Csk team has huge fan support";
  console.log(news1.concat(" csk won the IPL Champion 5th Time"));
  }}>concat</button>
  
  
  <button className = "button1" onClick={()=>{
  console.log(PMName.startsWith("Honour"));
  console.log(India.startsWith("unity"));
  
  }}>startsWith</button>
  
  
  <button className = "button1"onClick={()=>{
  
  console.log(PMName.endsWith("ji"));
  
  }}>endsWith</button>
  
  
  
  <button className = "button1" onClick={()=>{
  console.log(PMName.includes("Honourable"));
  
  }}>includes</button>
  
  
  
  <button className = "button1" onClick={()=>{
  
  let punishment = " I wont make any error in  mycode "
  console.log(punishment.repeat(100000));
  }}>repeat</button>
  
  
  <button className = "button1" onClick={()=>{
  
    let info = "India is incrediable country"
  
    console.log(info.toLowerCase());
    console.log(info.toUpperCase());
  }}>UpperCase,LowerCase</button>
  
  
  <button className = "button1" onClick={()=>{
    let countryName = "  Hamara  Bharath      ";
    let arry = 1+"3"*2;
    console.log(arry);
    console.log(`.........>>${countryName}<<<....`);
    console.log(`.........>>${countryName.trim()}<<<....`);
    console.log(`.........>>${countryName.trimEnd()}@@@<<<....`);
  }}>trim,trimStart,trimEnd</button>

    
<button className = "button1"onClick={()=>{
  
  
  
  for(let i=0;i<alphabets.length;i++)
  {
  console.log(alphabets.charAt(i));
  }
  
  
  
  console.log(alphabets.charCodeAt(0));

  for(let i=0;i<=alphabets.length;i++)
  {
    console.log(`${alphabets.charAt(i)}--*******>${alphabets.charCodeAt(i)}`);
    
  }
 
  
  }}>charCodeAt</button>

<button className = "button1" onClick={()=>{
  
    console.log(alphabets.charAt(5));
    console.log(alphabets.indexOf("C"));
    console.log(alphabets.lastIndexOf(5));



  }}>indexOf</button>
  
  <button className = "button1" onClick={()=>{
  
  let oldIndia = "Incrediable India";
  console.log(oldIndia.replace("Powerful Nation is India"));
  
  }}>replace</button>

<button className = "button1" onClick={()=>{
  
  let news1 = "India found natural resource";
  console.log(news1.search("natural"));
  
  }}>search</button>

<button className = "button1" onClick={()=>{
  
 console.log(alphabets.slice(10,15));
 console.log(alphabets.substr(10,15));
 console.log(alphabets.substring(10,15));
  
  
  }}>slice,substr,substring</button>

<button className = "button1" onClick={()=>{
  
  let news = "India is ranker top 1"
  let splittedArr = news.split(" ");
  console.log(splittedArr);
  
   
   }}>split</button>


<button className = "button1" onClick={()=>{
  
  let news = "CSK won the IPL Trophy 5th Time."
  let arr = news.match(/CSK/gi);
   
  console.log(arr);
   
   }}>merge</button>








    
      

</div>
  );
}

export default App;
 