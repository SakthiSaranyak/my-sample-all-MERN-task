import './App.css';
import {useRef} from "react";

function App() {
 
  let monthArr = ["january","February","March","Apirl","May","June","July","August","September","October","November","December"];
  let todaysDate = new Date();
  
  todaysDate.setFullYear(2045);
  todaysDate.setHours(3);
  console.log(todaysDate.getDate());
  console.log(monthArr[todaysDate.getMonth()]);
  console.log(todaysDate.getFullYear());
  console.log(todaysDate.getHours());
  console.log(todaysDate.getMinutes());
  console.log(todaysDate.getSeconds());
  console.log(todaysDate.getMilliseconds());
  
  let independenceDay = new Date(1938,7,15,15,45,20)

  console.log(independenceDay.getDate());
  console.log(monthArr[independenceDay.getMonth()]);
  console.log(independenceDay.getFullYear());
  console.log(independenceDay.getHours());
  console.log(independenceDay.getMinutes());
  console.log(independenceDay.getSeconds());
  console.log(independenceDay.getMilliseconds());
  
  let republicDay = new Date("1947-02-25")
  
  console.log(republicDay.getDate());
  console.log(monthArr[republicDay.getMonth()]);
  console.log(republicDay.getFullYear());
  console.log(republicDay.getHours());
  console.log(republicDay.getMinutes());
  console.log(republicDay.getSeconds());
  console.log(republicDay.getMilliseconds());
  
  return (
    <div className="App">
      <form>
        <div>
        
          
         <label>time now</label>
         
         <input type="time">
         
         
          
         </input>
        </div>
      </form>
      
    </div>
  );
}

export default App;
