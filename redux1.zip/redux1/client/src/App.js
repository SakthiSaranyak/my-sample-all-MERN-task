import logo from "./logo.svg";
import "./App.css";
import { useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import A from "./A";

function App() {
  let inputRef = useRef();
  let dispatch = useDispatch();

  let storeObj = useSelector((store) => {
    return store;
  });

  return (
    <div className="App">
      <input>ref={inputRef}</input>
      <button
        onClick={() => {
          let details = {
            type: "addActor",
            data: inputRef.current.value,
          };
          dispatch(details);
        }}
      >
        Add Actor
      </button>
      <A />
    </div>
  );
}

export default App;
