import React from "react";
import B from "./B";
function A() {
  return (
    <div>
      <B />
    </div>
  );
}

export default A;
