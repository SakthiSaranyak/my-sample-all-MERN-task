const mongoose = require("mongoose");
let connectToMDB = async () => {
  try {
    await mongoose.connect("mongodb://localhost:27017/Mern23");
    console.log("Connected to MDB");
    insertDataIntoDB();
  } catch (err) {
    if (err) {
      console.log("Unable to connect to db");
    }
  }
};

let studentSchema = new mongoose.Schema({
  name: {
    type: String,
    trim: true,
    validate: {
      validator: function (v) {
        return /^[a-zA-Z]{2,30}$/.test(v);
      },
      message: (props) => `${props.value} is not a valid name!`,
    },
    required: [true, "Name is mandatory"],
  },
  batchId: String,
  gender: {
    type: String,
    enum: ["male", "female"],
    required: true,
    lowercase: true,
  },
  maritalStatus: {
    type: String,
    enum: ["single", "married"],
    required: true,
    lowercase: true,
  },
  email: {
    type: String,
    trim: true,
    validate: {
      validator: function (v) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
      },
      message: (props) => `${props.value} is not a valid email!`,
    },
    required: [true, "Email is mandatory"],
  },
  mobileNo: String,
  age: {
    type: Number,
    min: [0, "You are too young to create account"],
    max: [100, "You are too old to create account"],
    required: [true, "Age is mandatory"],
  },
});

let Student = new mongoose.model("student", studentSchema);

let insertDataIntoDB = async () => {
  let saranya = new Student({
    name: "yy",
    batchId: "MERN 2303",
    gender: "Female",
    maritalStatus: "single",
    email: "saranya@gmail.com",
    mobileNo: "+91-786745678",
  });

  //await saranya.save();

  let SakthiSaranyaKamaraj = new Student({
    name: "ff",
    batchId: "MERN 2303",
    gender: "Female",
    maritalStatus: "single",
    email: "saranya223@gmail.com",
    mobileNo: "+91-786545668",
  });

  //await SakthiSaranyaKamaraj.save();

  await Student.insertMany([saranya, SakthiSaranyaKamaraj]);

  console.log("Inserted into db");
};

connectToMDB();
