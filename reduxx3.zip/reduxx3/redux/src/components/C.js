import React from "react";
import { useSelector } from "react-redux";
function C() {
  let storeObj = useSelector((store) => {
    return store;
  });
  return (
    <div>
      <h1>{storeObj.actors}</h1>
    </div>
  );
}

export default C;
