import React from "react";
import C from "./C.js";

function B() {
  return (
    <div>
      <C />
    </div>
  );
}

export default B;
