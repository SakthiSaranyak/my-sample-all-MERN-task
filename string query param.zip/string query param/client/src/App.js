import './App.css';
import {useEffect, useState, useRef} from "react";


function App() {
  let serialNo = 0;
  
  let countrySelectRef = useRef();
  let departmentSelectRef = useRef();
  let genderSelectRef = useRef();
  
  let [employees,setEmployees]= useState([]);
  let [countries,setCountries]= useState([]);
  let [departments,setDepartments]= useState([]);
  let [genders,setGenders]= useState([]);
  


  useEffect(()=>{
    console.log("sending requests");
   
    console.log(countries.length);
    console.log(departments.length);
   console.log(genders.length);
    if(countries.length === 0){
     
      getCountriesList();
      
      

    }
    if(departments.length === 0){
     
      getEmployeesDepartments();
    }
  
    if(genders.length === 0){
     getEmployeeesGenders();
  }
});

  let getDataFromServer = async ()=>{

    let reqOptions = {
      method:"GET",
    };

    let url = `http://localhost:4567/employees/${countrySelectRef.current.value}/${departmentSelectRef.current.value}/${genderSelectRef.current.value}`;

    let JSONData = await fetch(url,reqOptions);

    let JSOData = await JSONData.json();
    setEmployees(JSOData);

    console.log(JSOData);
  };

let getCountriesList = async()=>{
  let reqOptions = {
    method:"GET"
  };
  let JSONData = await fetch("http://localhost:4567/getCountries",reqOptions);

  let JSOData = await JSONData.json();
  setCountries(JSOData);
  console.log(JSOData);
};

let getEmployeesDepartments = async()=>{
  let reqOptions = {
    method:"GET"
  };
  let JSONData = await fetch("http://localhost:4567/getEmployeesDepartments",reqOptions);

  let JSOData = await JSONData.json();
  setDepartments(JSOData);
  console.log(JSOData);
};

let getEmployeeesGenders = async()=>{
  let reqOptions = {
    method:"GET"
  };
  let JSONData = await fetch("http://localhost:4567/getEmployeesGenders",reqOptions);

  let JSOData = await JSONData.json();
  setGenders(JSOData);
  console.log(JSOData);
};

  return (
    <div className="App">
      <form>
        <div>
          <label>Country</label>
          <select ref={countrySelectRef}>
            {countries.map((country)=>{

              return <option>{country.country}</option>;
            })}
          </select>
        </div>
        <div>
          <label>Department</label>
          <select ref={departmentSelectRef}>
            {departments.map((department)=>{

              return <option>{department.department}</option>;
            })}
          </select>
          
        </div>
        <div>
          <label>Gender</label>
          <select ref={genderSelectRef}>
            {genders.map((gender)=>{

              return <option>{gender.gender}</option>;
            })}
          </select>
        </div>
        
      <button type="button" onClick={()=>{
        getDataFromServer();
      }}>Get Employeess Details</button>
      </form>
      <table>
        <thead>
          <tr>
            <th>S.No.</th>
            <th>Id</th>
            <th>Profile Pic</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Age</th>
            <th>Gender</th>
            <th>email</th>
            <th>Department</th>
            <th>Country</th>
            
          </tr>
        </thead>
        <tbody>
          {employees.map((employees)=>{
            serialNo++;
            return(
        
          <tr key={serialNo}>
        <td>{serialNo}</td>
            <td>{employees.id}</td>
            <td><img className="profilePic" src={employees.profilePic}alt=""></img></td>
           <td>{employees.firstName}</td>
            <td>{employees.lastName}</td>
            <td>{employees.age}</td>
            <td>{employees.gender}</td>
            <td>{employees.email}</td>
            <td>{employees.department}</td>
            <td>{employees.country}</td>
           
            </tr>
             ); })}
            
             </tbody>
            
        <tfoot></tfoot>
      
      </table>
            
  
    </div>
  );
}


 export default App;