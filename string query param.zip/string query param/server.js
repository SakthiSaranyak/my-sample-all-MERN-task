const mysql = require("mysql");
const express = require("express");
const cors = require("cors");


let connection = mysql.createConnection({
   host:"localhost",
   port:3306,
   database:"populatingdata",
   user:"root",
   password:"root"


})

connection.connect((err)=>{
    if(err){
        console.log("Unable to connect to db");

    }else{
        console.log("Successfully connected to db");
    }
});

let app = express();
app.use(cors());

app.get("/getCountries",(req,res)=>{

    let query = `select distinct country from employees order by country asc`;

    connection.query(query,(err,results)=>{
  if(err){

    res.json(err);
  }else{
    res.json(results);
  }

})
});

app.get("/getDepartments",(req,res)=>{

    let query = `select distinct department from employees order by department asc`;

    connection.query(query,(err,results)=>{
  if(err){

    res.json(err);
  }else{
    res.json(results);
  }

})
});


app.get("/getGenders",(req,res)=>{

    let query = `select distinct gender from employees order by gender asc`;

    connection.query(query,(err,results)=>{
  if(err){

    res.json(err);
  }else{
    res.json(results);
  }

})
});



//connect db employee app.get
app.get("/employees",(req,res)=>{

    let query = `select * from employees`
    connection.query(query,(err,results)=>{
        if(err){
            res.json(err)
        }else{
            res.json(results);
        }

    })
});

    //instruct to the db to send data

app.get("/employees/:country/:department/:gender",(req,res)=>{

console.log(req.params);

let query = `select * from employees where country='${req.params.country}'and department='${req.params.department}'and gender='${req.params.gender}'`;

connection.query(query,(err,results)=>{

    if(err){
        res.json(err);
    }else{
        res.json(results);
    }
})

})

app.listen(4567,()=>{

   console.log("Listening to port 4567");
    

}

)