import React, {useRef} from 'react';
function SignUp() {

    let fnInputRef = useRef();
    let lnInputRef = useRef();
    let ageInputRef = useRef();
    let emailInputRef = useRef();
    let passwordInputRef = useRef();
    let mobileNoInputRef = useRef();
    let locationInputRef = useRef();
    let profilePicInputRef = useRef();
    let vedioFileInputRef = useRef();


    let sendSignUpDataToServer = async ()=>{

        

        let dataToSend = {
        
            fn:fnInputRef.current.value,
            ln:lnInputRef.current.value,
            age:ageInputRef.current.value,
            email:emailInputRef.current.value,
            password:passwordInputRef.current.value,
            mobileNo:mobileNoInputRef.current.value,
            location:locationInputRef.current.value,
            profilePic:profilePicInputRef.current.value,
            vedioFile:vedioFileInputRef.current.value,
            
        }

        let myHeaders = new Headers();
        myHeaders.append("content-type","application/json");

        let reqOptions = {
            method:"POST",
            body:JSON.stringify(dataToSend),
            headers:myHeaders,
        };
       

        let JSONData = await fetch("http://localhost:4445/signup",reqOptions);

        let JSOData = await JSONData.json();

        console.log(JSOData);
    };
    
return(

<div>
<form>
<div>

        



        <label>First Name</label>
        <input ref={fnInputRef}></input>
    </div>

    <div>
        <label>Last Name</label>
        <input ref={lnInputRef}></input>
    </div>

    <div>
        <label>Age</label>
        <input ref={ageInputRef}></input>
    </div>

    <div>
        <label>Email</label>
        <input ref={emailInputRef}></input>
    </div>

    <div>
        <label>Password</label>
        <input ref={passwordInputRef}></input>
    </div>
    <div>
        <label>MobileNo</label>
        <input ref={mobileNoInputRef}></input>
    </div>
    <div>
        <label>Location</label>
        <input ref={locationInputRef}></input>
    </div>
    <div>
        <label>Profile Pic</label>
        <input type="file" ref={profilePicInputRef}></input>
    </div>

    <div>
        <label>Vedio File</label>
        <input ref={vedioFileInputRef}></input>
    </div>
    <div>
       <button type="reset"onClick=
       {()=>{

        sendSignUpDataToServer();
       }}>SignUp</button>
    </div>
</form>

</div>





)
}

    

export default SignUp