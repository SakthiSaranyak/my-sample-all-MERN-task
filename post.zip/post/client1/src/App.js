import './App.css';
//export default App;
import SignUp from './components/SignUp';
import {useEffect, useState } from "react";
function App() {
  let [users,setUsers] = useState([]);
  useEffect(()=>{
    getDataFromServer();
  },[]);

  let getDataFromServer = async()=>{
    let reqOptions ={
      method:"GET",
    }
    let JSONData = await fetch("http://localhost:4445/studentinfo1",reqOptions);
    let JSOData = await JSONData.json();
    setUsers(JSOData);
    console.log(JSOData);
  }
  return (
    <div className="App">
      
      <SignUp/>
      <div>
        {/* <button onClick={()=>{
      getDataFromServer();
    }}/> */}
    <table className="table">
      <thead>
    <tr>
    <th>Id</th>
    <th>First Name</th>
    <th>Last Name</th>
    <th>Age</th>
    <th>Email Id</th>
    <th>Password</th> 
    <th>Mobile No</th>
    <th>Location</th>
    <th>Profile Pic</th>
    <th>Vedio File</th>

  </tr>
  </thead>
  <tbody>
    {users.map((user)=>{
      return(
        <tr key={user.id}>
    <td>{user.id}</td>
    <td>{user.firstName}</td>
    <td>{user.lastName}</td>
    <td>{user.age}</td> 
    <td>{user.email}</td>
    <td>{user.password}</td>
    <td>{user.mobileNo}</td>
    <td>{user.location}</td>
    <td><img className="profilePic" src={user.profilePic} alt=" "></img></td>
    <td>{user.vedioFile}</td>
      </tr>
      );
    })}
  </tbody>
    </table>
        </div>
      
    </div>
  );
}

export default App;
