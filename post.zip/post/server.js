const mysql = require("mysql");
const express = require("express");
const  cors = require("cors");


let connection = mysql.createConnection({

    host:"localhost",
    port:3306,
    user:"root",
    password:"root",
    database:"saranya",

})

connection.connect((err)=>{
    if(err){
        console.log("Unable to connect to db");
    }else{
        console.log("Successfully connect to db");
    }
})

const app = express();
app.use(cors());
app.use(express.json());

//select data from database

app.get("/studentinfo1",(req,res)=>{

    let query = `select * from studentinfo1`;

    connection.query(query,(err,results)=>{

        if(err){
            res.json(err);
        }else{
            res.json(results);
        }
    });
})

app.post("/signup",(req,res)=>{
     

    console.log(req.body);
    let query = `insert into studentinfo1(firstName,lastName,age,email,password,mobileNo,location,profilePic,vedioFile) values ('${req.body.fn}','${req.body.ln}',${req.body.age},'${req.body.email}','${req.body.password}','${req.body.mobileNo}','${req.body.location}'
    '${req.body.profilePic}','${req.body.vedioFile}')`;
   

     connection.query(query,(err,results)=>{

        if(err){
            res.json(err);
        }else{
            res.json({status:"success",msg:"Account created successfully"});
        }
    });
     
});
connection.connect((err)=>{
    if(err){
        console.log("unable to connect to database");
    }
    getDataFromDB();
});

let getDataFromDB = ()=>{
    let query = `select * from studentinfo1`;
    connection.query(query,(err,results)=>{
        if(err){
            console.log("something is wrong");
        }else{
            console.log(results);
        }
    });
}



app.listen(4445,()=>{

    console.log("Listening to the port 4445")
});