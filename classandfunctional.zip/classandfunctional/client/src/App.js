import "./App.css";
import CCounter from "./components/CCounter.js";
import FCCounter from "./components/FCCounter.js";
import { useState } from "react";

function App() {
  let [showComponents, setShowComponents] = useState(true);

  return (
    <div className="App">
      <button
        onClick={() => {
          setShowComponents(!showComponents);
        }}
      >
        Show/Hide component
      </button>
      <br></br>
      <br></br>
      {showComponents == true ? <FCCounter /> : null}
      {<CCounter />}
    </div>
  );
}

export default App;
