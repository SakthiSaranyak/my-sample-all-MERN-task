import React, { useEffect, useState } from "react";

function FCCounter() {
  let [score, setScore] = useState(0);
  let [marks, setMarks] = useState(0);

  useEffect(() => {
    console.log("FC-Counter-score sv changed");
  }, [score]);

  useEffect(() => {
    console.log("FC-Counter-marks sv changed");
  }, [marks]);

  useEffect(() => {
    console.log("FC-Counter-score or marks sv changed");
  }, [score, marks]);

  useEffect(() => {
    console.log("FC-Counter- sv changed");
  });

  //component loads
  useEffect(() => {
    console.log("FC-Counter-onLoad");
  }, []);

  //component unloads
  useEffect(() => {
    return () => {
      console.log("FC-Counter-unLoad");
    };
  }, []);

  return (
    <div className="counter">
      <h2>Functional Component</h2>
      <h1>Score:{score}</h1>
      <h1>Marks:{marks}</h1>
      <button
        onClick={() => {
          setScore(score + 1);
        }}
      >
        Increase Score
      </button>
      <br></br>
      <br></br>
      <button
        onClick={() => {
          setScore(score - 1);
        }}
      >
        Decrease Score
      </button>
      <br></br>
      <br></br>

      <button
        onClick={() => {
          setMarks(marks + 1);
        }}
      >
        Increase Marks
      </button>
      <br></br>
      <br></br>
      <button
        onClick={() => {
          setMarks(marks - 1);
        }}
      >
        Decrease Marks
      </button>
      <br></br>
      <br></br>
    </div>
  );
}

export default FCCounter;
