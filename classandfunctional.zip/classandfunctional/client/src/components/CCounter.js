import React, { Component, PureComponent } from "react";

export default class CCounter extends Component {
  constructor(props) {
    super(props);

    this.state = {
      score: 0,
      marks: 0,
    };
  }
  //component onLoad

  componentDidMount() {
    console.log("CC-OnLoad");
  }

  componentWillUnmount() {
    console.log("CC-UNLoad");
  }

  //shouldComponentUpdate(nextProps, nextState) {
  // console.log("CC-shouldComponentUpdate");
  // console.log(nextState);
  //console.log(this.state);

  //if (nextState.score == this.state.score) {
  //  return false;
  // } else {
  //   return true;
  // }

  //return true;
  //}

  //return true;

  componentDidUpdate() {
    console.log("CC-componentDidUpdate");
    return true;
  }

  render() {
    console.log("CC-render");
    return (
      <div className="counter" style={{ backgroundColor: "cornsilk" }}>
        <h2>Class Componenet</h2>
        <h1>Score:{this.state.score}</h1>
        <h1>Marks:{this.state.marks}</h1>
        <button
          onClick={() => {
            // setScore(score + 1);
            this.setState({ score: this.state.score + 1 });
          }}
        >
          Increase Score
        </button>
        <br></br>
        <br></br>
        <button
          onClick={() => {
            //setScore(score - 1);
            this.setState({ score: this.state.score - 1 });
          }}
        >
          Decrease Score
        </button>
        <br></br>
        <br></br>

        <button
          onClick={() => {
            //setMarks(marks + 1);
            this.setState({ score: 100 });
          }}
        >
          Assign 100
        </button>
        <br></br>
        <br></br>
        <button
          onClick={() => {
            // setScore(score + 1);
            this.setState({ score: this.state.score + 1 });
          }}
        >
          Increase Marks
        </button>
        <br></br>
        <br></br>
        <button
          onClick={() => {
            //setMarks(marks - 1);
            this.setState({ marks: this.state.marks - 1 });
          }}
        >
          Decrease Marks
        </button>
        <br></br>
        <br></br>
      </div>
    );
  }
}
